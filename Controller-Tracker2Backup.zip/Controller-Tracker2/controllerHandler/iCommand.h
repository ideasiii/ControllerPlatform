/*
 * ICallback.h
 *
 *  Created on: 2016年11月1日
 *      Author: Jugo
 */

#pragma once

#define CB_CONTROLLER_MONGODB_COMMAND			1


